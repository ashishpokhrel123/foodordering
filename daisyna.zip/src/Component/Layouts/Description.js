import React, { Component } from 'react'
import { Row } from 'reactstrap'

export default class Container extends Component {
    render() {
        return (
           
                <Container>
                    <Row>
                     <col>
                     <h1>Healthy Eating Reinvented</h1>
                     </col>
                    </Row>
                 
                </Container>

                
         
        )
    }
}

